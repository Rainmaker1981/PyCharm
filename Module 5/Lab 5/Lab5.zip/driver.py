from Car import Car
from Truck import Truck

def main():
    c1 = Car("Plymouth", "Cuda", 1971, 1478, 27, 2)
    t1 = Truck("Chevy", "K10", 1984, 2200, 40, 4)
    print(c1)
    print(t1)

if __name__ == "__main__":
    main()